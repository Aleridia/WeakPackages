The secrets API_KEY, DB_PASSWORD & TOKEN are from the default gitleaks rules.
The secret KRAKEN is from the enhanced rules.