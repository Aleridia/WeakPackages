#ifndef DATABASE_H
#define DATABASE_H

void initDatabase();
void runQuery(const char *userInput);
void closeDatabase();

#endif // DATABASE_H
