#!/bin/sh
echo "Bad scripting"